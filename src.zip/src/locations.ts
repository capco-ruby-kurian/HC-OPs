export const data1 = [{
    "countries": "India",
    "states":
    [
        {
            "state": "Maharashtra",
            "cities":
            ["Pune", "Bombay", "Kolhapur"]
        },
        {
            "state": "Karnataka",
            "cities":
            ["Bangalor", "Magalore", "Belgum"]
        },

    ]
}];