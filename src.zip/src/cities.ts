export const location = [{
    "locationId": 1,
    "Country": "India",
    "State": "Maharashtra",
    "City": "Pune"
},
{
    "locationId": 2,
    "Country": "India",
    "State": "Karnataka",
    "City": "Bangalore"
}

];