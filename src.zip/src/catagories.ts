export const catagory = [{
    "CatagoryId": 1,
    "CatagoryName": "On-Boarding",
    "SubCatagory": {
        "OP1":"Induction Timelines",
        "OP2":"PF Transfer",
        "OP3":"Howden",
        "OP4":"Laptop",
        "OP5": "Id Card",
        "OP6":"Access Card",
    }
},
{
    "CatagoryId": 2,
    "CatagoryName": "Exit-Off-Boarding",
    "SubCatagory": {
        "OP1":"FnF related querie",
        "OP2":"FNF documents",
        "OP3":"Retention Bonus Recovery",
        "OP4":"Leave Encashment Calculation",
        "OP5":"Checklist for exit ",
        "OP6":"Project code for Timesheet updation",
        "OP7":"Resignation acceptance letter",
        "OP8":"Exit Process Explanation",
    }
},
{
    "CatagoryId": 3,
    "CatagoryName": "Payroll",
    "SubCatagory":{
        "OP1": "Request for Weblink of ADP",
        "OP2":"Request for password reset",
        "OP3":"Request correct credentials",
        "OP4":"IT and FBP Declaration",
        "OP5":"Breakup of management allowance",
        "OP6":"Shift Allowance/On Call allowance",
        "OP7":"Resignation acceptance letter",
        "OP8":"LOP Calculation",
        "OP9":"Leave encashment",
        "OP10": "National Holiday Payout",
        "OP11":"Other deductions",
        "OP12":"Salary Hold cases",
    }
},];

