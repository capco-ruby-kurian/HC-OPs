import { Injectable } from '@angular/core';
import{Http, Response, RequestOptions, Headers} from '@angular/http';
import { Observable } from "rxjs/Observable";
import { HttpClient, HttpEvent, HttpRequest } from "@angular/common/http";

@Injectable()
export class ProfilepicService {
     getFiles(): any {
        throw new Error("Method not implemented.");
    }

  constructor(private http: HttpClient) { }
  
    pushFileToStorage(file: File,object:object): Observable<HttpEvent<{}>> {
      debugger;
      const formdata: FormData = new FormData();
  
      formdata.append('file', file);
      
      debugger;
      const req = new HttpRequest('POST','http://localhost:8080/incident/incidentWithAttachment', formdata, {
       
        reportProgress: true,
        
        responseType: 'text'
      });
  
      return this.http.request(req);
    }
  
   
  
}
