import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-active',
  templateUrl: './admin-active.component.html',
  styleUrls: ['./admin-active.component.scss']
})
export class AdminActiveComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
