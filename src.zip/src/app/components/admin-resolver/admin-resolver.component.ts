import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { EditServiceService } from '../../providers/edit-service.service';

@Component({
  selector: 'app-admin-resolver',
  templateUrl: './admin-resolver.component.html',
  styleUrls: ['./admin-resolver.component.scss']
})
export class AdminResolverComponent implements OnInit {
  form: FormGroup;
  incNo; description; assignedto; created; req;

  public assignedData: any[];
  user = { state: '', usr: '' };
  constructor(private es: EditServiceService) {
  this.assignedData = this.es.actRow;
    console.log('data in admin resolver ', this.assignedData);
    // this.incNo=this.assignedData[0].INC;
    // this.incNo = this.assignedData.INC;
    // this.req = this.assignedData.Requestor;
    // this.assignedto = this.assignedData.AssignedTo;
    // this.created = this.assignedData.Created;
    // this.description = this.assignedData.Description;
  }


  ngOnInit(): void {
    this.form = new FormGroup({
      'state': new FormControl(this.user.state, [
        Validators.required
      ]),
      'usr': new FormControl(this.user.usr, [
        Validators.required
      ])
    });



  }
  populate() {
    for (let i = 0; i < this.assignedData.length; i++) {
      // this.es.assignedRow.push(this.assignedData[i]);

    }
  }
}
