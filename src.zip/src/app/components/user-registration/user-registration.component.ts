import { Component, OnInit } from '@angular/core';
import { HttpXrsService } from '../../providers/http-xrs.service';
import { FormsModule } from '@angular/forms';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-registration',
  templateUrl: './user-registration.component.html',
  styleUrls: ['./user-registration.component.scss']
})
export class UserRegistrationComponent implements OnInit {
  c: any;
  ste: any;
  ctry: any;
  cit: any;
  st: any;
  cunt :any;
  cnt : any;
  locations=[];

  states = [];
  cities = [];
 
  departments = ['HC OPS'];
  userGroups = ['HC OPS', 'Users'];

  // tslint:disable-next-line:max-line-length
  user = { userId: '', email: '', city: '', state:'', country: 'select country', department: this.departments[0], userGroup: this.userGroups[0] };

  constructor(public newuserserv: HttpXrsService,private locationservice: HttpXrsService) { }

  userForm: FormGroup;

  ngOnInit(): void {

    this.locationservice.httprequest({ type: 'GET', url: './assets/data/locations.json', data: {} })
    .then((data: any) => {
      this.setQueryOptionsData(data);
      console.log(data)
    });

    this.userForm = new FormGroup({
      'userId': new FormControl(this.user.userId, [
        Validators.required,
        Validators.minLength(4),
        Validators.maxLength(4),
      ]),
      'email': new FormControl(this.user.email, [
        Validators.required,
        Validators.pattern('^[A-Za-z]+.[^A-Za-z][^@]+@capco.com'),
        //  Validators.pattern("[^ @]*@[^ @]*")

      ]),
      'city': new FormControl(this.user.city, Validators.required),
      'state': new FormControl(this.user.state, Validators.required),
      'country': new FormControl(this.user.country, Validators.required),
      'department': new FormControl(this.user.department, Validators.required),
      'userGroup': new FormControl(this.user.userGroup, Validators.required),

    });

      // GET  Data
      this.newuserserv.httprequest({ type: 'GET', url: './assets/data/locations.json', data: {}})
      .then((data: any) => {
        console.log('add user component ', data.locations);
        this.user = data.locations;
      });
  }

  setQueryOptionsData(data: any) {
    this.locations = data.locations;
    this.ctry = data.countryName;
    this.states = data.states;
    this.ste = data.stateName;
    this.cities = data.cities;
    
}
  setOptions(){
    for (let i = 0; i < this.locations.length; i++) { 
  if (this.locations[i].countryName == this.cnt) {
           this.cunt = this.locations[i].states;
          for (let z = 0; z < this.cunt.length; z++) {
          if (this.cunt[z].stateName == this.st) {
            this.cit = this.cunt[z].cities;
          }
        }

      }
    }
  }



  
  saveAddNewUserForm() {
    let user = {
      userIdservevr: this.userId.value,
      useremailservevar: this.email.value,
      cityservevar: this.city.value,
      stateservevar: this.state.value,
      countryservevar: this.country.value,
      deptservevar: this.department.value,
      usergroupservevar: this.userGroup.value,
    }
    console.log(user);  

    // Post Data
    this.newuserserv.httprequest({ type: 'POST', url: '', data: { user } })
      .then((data) => {
        if (data) {
          console.log('res :', data);
          console.log('Registration sucessfull');
        } else {
          console.log('Registration Unsucessfull');
        }
        console.log(data);
      });
  }
  get userId() { return this.userForm.get('userId'); }
  get email() { return this.userForm.get('email'); }
  get city() { return this.userForm.get('city'); }
  get state() { return this.userForm.get('state'); }
  get country() { return this.userForm.get('country'); }
  get department() { return this.userForm.get('department'); }
  get userGroup() { return this.userForm.get('userGroup'); }

}


