import { Component, OnInit } from '@angular/core';
import { HttpXrsService } from '../../providers/http-xrs.service';
@Component({
  selector: 'app-admin-country',
  templateUrl: './admin-country.component.html',
  styleUrls: ['./admin-country.component.scss']
})
export class AdminCountryComponent implements OnInit {
  gridData=[];
  constructor(private location:HttpXrsService) { }
  countryForm = { country: '', state: '',city:'' };
  ngOnInit() {
    this.location.httprequest({ type: 'GET', url: './assets/data/locations.json', data: {} })
    .then((data: any) => {
      this.gridData=data.locations;
      console.log("Grid data",this.gridData)
    });
  }

  getRow(evt){
    this.location.state=evt.dataItem.states;
    console.log("helloooooooo",this.location.state);
}

}
