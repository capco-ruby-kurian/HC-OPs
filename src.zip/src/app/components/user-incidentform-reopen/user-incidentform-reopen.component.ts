import { HttpXrsService } from './../../providers/http-xrs.service';
import { HttpRequest } from '@angular/common/http';

import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-user-incidentform-reopen',
  templateUrl: './user-incidentform-reopen.component.html',
  styleUrls: ['./user-incidentform-reopen.component.scss']
})
export class UserIncidentformReopenComponent implements OnInit {
  sub=[];
  cat: any;
  Subcategories = [];
  categories=[];
  name:any;
  cities = ['IN>Pune', 'IN>Banglore'];

  user = {incidentNo: '', state: '', city:'',categories:'',sub:'',description:'',solution:''};

  constructor(private categoryservice:HttpXrsService) { }

  reopenForm: FormGroup;
  ngOnInit():void{
    this.reopenForm = new FormGroup({
      'city': new FormControl(this.user.city, Validators.required),
      'category': new FormControl(this.user.categories, Validators.required),
      'subCategory': new FormControl(this.user.sub, Validators.required),
      'description': new FormControl(this.user.description, Validators.required),
      'solution': new FormControl(this.user.solution, Validators.required),
    });
    this.categoryservice.httprequest({ type: 'GET', url: './assets/data/categories.json', data: {} })
    .then((data: any) => {
      this.setQueryOptionsData(data);
      console.log(data)
    });
  }
  setQueryOptionsData(data: any) {
    this.categories=data.categories;
    this.name = data.name;
    this.Subcategories = data.Subcategories;
    }
    setOptions(){
      for(let i=0;i<this.categories.length;i++){
        if(this.categories[i].name==this.cat){
          this.sub=this.categories[i].Subcategories;
        }
      }
    }

  get city() { return this.reopenForm.get('city'); }
  get category() { return this.reopenForm.get('category'); }
  get subCategory() { return this.reopenForm.get('subCategory'); }
  get description() { return this.reopenForm.get('description'); }
  get solution() { return this.reopenForm.get('solution'); }

}



