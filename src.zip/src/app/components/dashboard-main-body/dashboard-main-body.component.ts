import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-dashboard-main-body',
  templateUrl: './dashboard-main-body.component.html',
  styleUrls: ['./dashboard-main-body.component.scss']
})
export class DashboardMainBodyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
