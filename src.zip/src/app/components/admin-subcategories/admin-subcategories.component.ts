import { Component, OnInit, TemplateRef, ElementRef, Inject, Input } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Http } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import { GridDataResult, GridComponent, PageChangeEvent } from '@progress/kendo-angular-grid';
import { State, process } from '@progress/kendo-data-query';
import { HttpXrsService } from '../../providers/http-xrs.service';
import { map } from 'rxjs/operators/map';
import { CategorysubcategoryService } from '../../providers/categorysubcategory.service';
import { Router } from '@angular/router';
import { EditServiceService } from '../../providers/edit-service.service';


const createFormGroup = dataItem => new FormGroup({
    'subcategoryName': new FormControl(dataItem.subcategoryName),
});
@Component({
    selector: 'app-admin-subcategories',
    templateUrl: './admin-subcategories.component.html',
    styleUrls: ['./admin-subcategories.component.scss']
})
export class AdminSubcategoriesComponent implements OnInit {


    r: any;
    public gridData = [];
    public sss: String;
    public formGroup: FormGroup;
    private editedRowIndex: number;
    public data = [];
    public skip = 0;
    /**
        * The subcategory for category are displayed
    */
    constructor(private categoryservice: HttpXrsService, private categorysubcategory: CategorysubcategoryService, public router: Router, public es: EditServiceService) {

    }
    ngOnInit() {
        this.gridData = this.categoryservice.sub;
        console.log("subcategory display:", this.gridData);
    }

    public category(name: string): any {
        return this.data.find(x => x.subcategoryName === name);
    }

    public addHandler({ sender }) {
        this.closeEditor(sender);

        this.formGroup = createFormGroup({
            'subcategoryName': '',
        });
        sender.addRow(this.formGroup);
    }

    public editHandler({ sender, rowIndex, dataItem }) {
        this.closeEditor(sender);
        this.formGroup = createFormGroup(dataItem);
        this.editedRowIndex = rowIndex;
        sender.editRow(rowIndex, this.formGroup);
    }

    public cancelHandler({ sender, rowIndex }) {
        this.closeEditor(sender, rowIndex);
    }

    public saveHandler({ dataItem, sender, rowIndex, formGroup, isNew }): void {
        const subcategory = formGroup.value;
        //start
        console.log("post data", subcategory);
        this.categoryservice.httprequest({ type: 'POST', url: '', data: subcategory })
            .then((data) => {
                if (data) { console.log("data  saved:", data); }
                else {
                    console.log("error");
                }
            });
        // update the data source
        this.es.save(subcategory, isNew);
        // close the editor, that is, revert the row back into view mode
        sender.closeRow(rowIndex);
    }


    public removeHandler({ dataItem }): void {
        this.categorysubcategory.remove(dataItem);
        console.log("delete data", dataItem);
    }

      // Delete the selected data
  removeItems(i){ 
    console.log(i);
   // this.gridData.splice(i, 1);
   this.categoryservice.httprequest({ type: 'DELETE', url: '', data:{} })
   .then((data) => {
     if (data) {
       console.log("data deleted :", data);
       
     }
     else {
       console.log("error");
     }
   });
 }

    private closeEditor(grid, rowIndex = this.editedRowIndex) {
        grid.closeRow(rowIndex);
        this.editedRowIndex = undefined;
        this.formGroup = undefined;
    }

}
