import { Component, OnInit } from '@angular/core';
import { HttpXrsService } from '../../providers/http-xrs.service';
import { FormControl,FormGroup,Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs/Rx';
import { EditServiceService } from '../../providers/edit-service.service';

@Component({
  // tslint:disable-next-line:component-selector
  selector: 'user-group',
  templateUrl: './user-group.component.html',
  styleUrls: ['./user-group.component.scss']
})
export class UserGroupComponent implements OnInit {
  public gridData: any;
  public formGroup: FormGroup;
  constructor(public userGroupServe: HttpXrsService, public router: Router,public es:EditServiceService) { }
  userGroup = { grpcode: '', grpname: '' };
  ngOnInit() {
    /**
   * @param type endpoint for which we get the json data
   */
    this.userGroupServe.httprequest({ type: 'GET', url: './assets/data/group.json', data: {}})
      .then((data: any) => {
        console.log('user group component ', data.groups);
        this.gridData = data.groups;
      });

  }
   // Delete the selected data
  removeItems(i){ 
     console.log(i);
    // this.gridData.splice(i, 1);
    this.userGroupServe.httprequest({ type: 'DELETE', url: '', data:{} })
    .then((data) => {
      if (data) {
        console.log("data :", data);
        
      }
      else {
        console.log("error");
      }
    });
  }

  editRow(dataItem){
    console.log(dataItem);
    this.formGroup = new FormGroup({
      'GRCode': new FormControl(dataItem.GRCode,Validators.pattern('^[0-9]{1,3}')),
      'GRName': new FormControl(dataItem.ProductName, Validators.required),
       })
  }
  protected editHandler({sender, rowIndex, dataItem}) {
    // define all editable fields validators and default values
    const group = new FormGroup({
      'GRCode': new FormControl(dataItem.GRCode,Validators.pattern('^[0-9]{1,3}')),
      'GRName': new FormControl(dataItem.ProductName, Validators.required),
    });

    // put the row in edit mode, with the `FormGroup` build above
    sender.editRow(rowIndex, group);
}

protected addHandler({sender}) {
  // define all editable fields validators and default values
  const group = new FormGroup({
      'GRCode': new FormControl("",Validators.pattern('^[0-9]{1,3}')),
      'GRName': new FormControl("", Validators.required),
  });

  // show the new row editor, with the `FormGroup` build above
  sender.addRow(group);
}

protected cancelHandler({sender, rowIndex}) {
  // close the editor for the given row
  sender.closeRow(rowIndex)
}

protected saveHandler({sender, rowIndex, formGroup, isNew}) {
  // collect the current state of the form
  // `formGroup` arguments is the same as was provided when calling `editRow`
  const product=formGroup.value;
   console.log("post data",product);
  this.userGroupServe.httprequest({ type: 'POST', url: '', data:product })
    .then((data) => {
      if (data) { console.log("data :", data);}
      else {
        console.log("error");
      }
    });
  // update the data source
  this.es.save(product, isNew); 
  // close the editor, that is, revert the row back into view mode
  sender.closeRow(rowIndex);
}

}
