export const groups=[{
   "GRID":1,
   "GRCode":"IS",
   "GRName":"Approver" 
},
{
    "GRID":2,
    "GRCode":"ITC",
    "GRName":"IT Coordinator" 
 },
 {
    "GRID":3,
    "GRCode":"ATC",
    "GRName":"Admin telephone Coordinator" 
 },
 {
    "GRID":4,
    "GRCode":"ASC",
    "GRName":"Admin Seat Coordinator" 
 },
 {
    "GRID":5,
    "GRCode":"RDSR",
    "GRName":"Read/Search" 
 },
 {
    "GRID":6,
    "GRCode":"RDSR",
    "GRName":"Read/Search" 
 },
 {
    "GRID":7,
    "GRCode":"CKLT",
    "GRName":"CheckList" 
 }];