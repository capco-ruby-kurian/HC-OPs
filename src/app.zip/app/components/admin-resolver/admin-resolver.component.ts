import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-resolver',
  templateUrl: './admin-resolver.component.html',
  styleUrls: ['./admin-resolver.component.scss']
})
export class AdminResolverComponent implements OnInit {

  constructor() { }

  ngOnInit() {
    
  }

}
