import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-addnewcities',
  templateUrl: './admin-addnewcities.component.html',
  styleUrls: ['./admin-addnewcities.component.scss']
})
export class AdminAddnewcitiesComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
