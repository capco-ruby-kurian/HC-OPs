import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-addnewgroups',
  templateUrl: './admin-addnewgroups.component.html',
  styleUrls: ['./admin-addnewgroups.component.scss']
})
export class AdminAddnewgroupsComponent implements OnInit {
 
  constructor() { }

  ngOnInit() {
  }

}
